#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NAME_LEN 60
#define DEPT_LEN 40

typedef struct Student {
    int id;
    char name[NAME_LEN];
    char department[DEPT_LEN];
    struct Student *left, *right;
} Student;

int comparisons = 0;
Student *createNode(int id, const char *name, const char *dept) {
    Student *n = (Student *)malloc(sizeof(Student));
    if (!n) { printf("Memory allocation failed.\n"); exit(EXIT_FAILURE); }
    n->id = id; snprintf(n->name, NAME_LEN, "%s", name);
    snprintf(n->department, DEPT_LEN, "%s", dept); n->left = n->right = NULL;
    return n;
}
Student *search(Student *root, int id) {
    while (root) { comparisons++; if (id == root->id) return root; root = id < root->id ? root->left : root->right; }
    return NULL;
}
Student *insert(Student *root, int id, const char *name, const char *dept) {
    if (!root) return createNode(id, name, dept);
    comparisons++;
    if (id < root->id) root->left = insert(root->left, id, name, dept);
    else if (id > root->id) root->right = insert(root->right, id, name, dept);
    else printf("Duplicate enrolment ID %d rejected.\n", id);
    return root;
}
Student *minimumNode(Student *root) { while (root && root->left) root = root->left; return root; }
Student *deleteNode(Student *root, int id, int *deleted) {
    if (!root) return NULL;
    comparisons++;
    if (id < root->id) root->left = deleteNode(root->left, id, deleted);
    else if (id > root->id) root->right = deleteNode(root->right, id, deleted);
    else {
        Student *tmp; *deleted = 1;
        if (!root->left) { tmp = root->right; free(root); return tmp; }
        if (!root->right) { tmp = root->left; free(root); return tmp; }
        tmp = minimumNode(root->right);
        root->id = tmp->id; snprintf(root->name, NAME_LEN, "%s", tmp->name);
        snprintf(root->department, DEPT_LEN, "%s", tmp->department);
        root->right = deleteNode(root->right, tmp->id, deleted);
    }
    return root;
}
void printRecord(const Student *n) { printf("ID: %d | Name: %s | Department: %s\n", n->id, n->name, n->department); }
void inorder(Student *r) { if (r) { inorder(r->left); printRecord(r); inorder(r->right); } }
void preorder(Student *r) { if (r) { printRecord(r); preorder(r->left); preorder(r->right); } }
void postorder(Student *r) { if (r) { postorder(r->left); postorder(r->right); printRecord(r); } }
int height(Student *r) { int l,h; if (!r) return 0; l=height(r->left); h=height(r->right); return 1+(l>h?l:h); }
void freeTree(Student *r) { if (r) { freeTree(r->left); freeTree(r->right); free(r); } }
void clearLine(void) { int c; while ((c=getchar())!='\n' && c!=EOF) {} }
void readText(const char *prompt, char *out, size_t size) {
    size_t n; printf("%s",prompt);
    if (!fgets(out,(int)size,stdin)) { out[0]='\0'; return; }
    n=strlen(out); if(n && out[n-1]=='\n') out[n-1]='\0'; else clearLine();
}
void addPrompt(Student **root) {
    int id; char name[NAME_LEN],dept[DEPT_LEN];
    printf("Enter enrolment ID (integer): ");
    if(scanf("%d",&id)!=1) { printf("Invalid ID.\n"); clearLine(); return; } clearLine();
    comparisons=0;
    if(search(*root,id)) { printf("Duplicate enrolment ID %d rejected.\n",id); return; }
    readText("Enter student name: ",name,sizeof(name)); readText("Enter department/programme: ",dept,sizeof(dept));
    if(!name[0] || !dept[0]) { printf("Name and department cannot be empty.\n"); return; }
    *root=insert(*root,id,name,dept); printf("Record inserted.\n");
}
void loadSamples(Student **root) {
    const int ids[]={50,30,70,20,40,60,80,10,35,65};
    const char *names[]={"Aarav","Diya","Kabir","Meera","Arjun","Isha","Vivaan","Anaya","Reyansh","Saanvi"};
    const char *depts[]={"CSE","ECE","CSE","IT","CSE","ME","ECE","IT","CSE","ME"};
    int i; for(i=0;i<10;i++) { if(!search(*root,ids[i])) *root=insert(*root,ids[i],names[i],depts[i]); }
    printf("Sample records loaded (existing IDs are not duplicated).\n");
}
void compareOrders(void) {
    const int a[]={50,30,70,20,40,60,80,10,35,65};
    const int b[]={10,20,30,35,40,50,60,65,70,80};
    Student *x=NULL,*y=NULL; int i,c1,c2; char name[NAME_LEN];
    comparisons=0; for(i=0;i<10;i++) { snprintf(name,sizeof(name),"Student%d",a[i]); x=insert(x,a[i],name,"CSE"); } c1=comparisons;
    comparisons=0; for(i=0;i<10;i++) { snprintf(name,sizeof(name),"Student%d",b[i]); y=insert(y,b[i],name,"CSE"); } c2=comparisons;
    printf("Balanced-looking order: height=%d, insertion comparisons=%d\n",height(x),c1);
    printf("Sorted order:           height=%d, insertion comparisons=%d\n",height(y),c2);
    printf("A regular BST can become skewed with sorted insertion.\n"); freeTree(x); freeTree(y); comparisons=0;
}
int main(void) {
    Student *root=NULL,*found; int choice,id,deleted;
    do {
        printf("\n=== STUDENT RECORD BST (C) ===\n1. Insert record\n2. Search by ID\n3. Delete by ID\n4. Inorder (sorted)\n5. Preorder\n6. Postorder\n7. Load 10 sample records\n8. Compare insertion orders\n9. Show tree height\n0. Exit\nChoice: ");
        if(scanf("%d",&choice)!=1) { printf("Invalid input.\n"); clearLine(); continue; } clearLine();
        switch(choice) {
            case 1: addPrompt(&root); break;
            case 2: printf("Enrolment ID to search: "); if(scanf("%d",&id)!=1){printf("Invalid ID.\n");clearLine();break;} clearLine(); comparisons=0; found=search(root,id); if(found) printRecord(found); else printf("Student ID %d not found.\n",id); printf("Search comparisons: %d\n",comparisons); break;
            case 3: printf("Enrolment ID to delete: "); if(scanf("%d",&id)!=1){printf("Invalid ID.\n");clearLine();break;} clearLine(); deleted=0; comparisons=0; root=deleteNode(root,id,&deleted); if(deleted) printf("Record deleted.\n"); else printf("Student ID %d not found.\n",id); break;
            case 4: if(root) { printf("Records in ascending ID order:\n"); inorder(root); } else printf("Tree is empty.\n"); break;
            case 5: if(root) { printf("Preorder traversal:\n"); preorder(root); } else printf("Tree is empty.\n"); break;
            case 6: if(root) { printf("Postorder traversal:\n"); postorder(root); } else printf("Tree is empty.\n"); break;
            case 7: loadSamples(&root); break;
            case 8: compareOrders(); break;
            case 9: printf("Tree height: %d\n",height(root)); break;
            case 0: printf("Exiting.\n"); break;
            default: printf("Invalid menu choice.\n");
        }
    } while(choice!=0);
    freeTree(root); return 0;
}
