# Student Record Search System Using BST (C)

A menu-driven C11 mini project. Each student record stores a unique enrolment ID, name and department. The enrolment ID is the BST key.

## Features
- Insert records and reject duplicate IDs.
- Search and delete records.
- Handles deletion of leaf, one-child and two-child nodes.
- Inorder, preorder and postorder traversals.
- Load ten sample records and compare insertion orders by tree height/comparison count.

## Compile and run
```bash
gcc -std=c11 -Wall -Wextra -pedantic main.c -o student_bst
./student_bst
```
Windows MinGW:
```bash
gcc -std=c11 -Wall -Wextra -pedantic main.c -o student_bst.exe
.\student_bst.exe
```

## Quick demonstration
1. Select `7` to load sample records.
2. Select `4` to see IDs in ascending order.
3. Select `2` and search ID `40`.
4. Select `3` and delete ID `10` (leaf), ID `60` (one child in the initial sample), or ID `50` (two children in the initial sample). Deleting ID `60` demonstrates the one-child case in the initial sample because it has child ID `65`.
5. Select `8` to compare two insertion orders.

## Complexity
Let `n` be records and `h` be tree height. Insert/search/delete are `O(h)`, average `O(log n)` in a reasonably balanced tree and worst-case `O(n)` in a skewed tree. Traversals take `O(n)` time. Storage is `O(n)` and recursive stack usage is `O(h)`. A regular BST is not self-balancing; AVL trees use rotations to maintain `O(log n)` height.

## GitHub upload
```bash
git init
git add .
git commit -m "Add Student Record BST in C"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-record-bst-c.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.
