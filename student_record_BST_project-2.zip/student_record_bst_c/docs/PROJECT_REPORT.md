# Project Report: Student Record Search System Using Trees

## Aim
Implement student record management using a Binary Search Tree (BST) in C.

## Problem statement
Each record contains a unique enrolment ID, student name and department/programme. The ID is used as the BST key. The system supports insertion, searching, deletion and traversal.

## BST property
For each node, all IDs in its left subtree are smaller and all IDs in its right subtree are greater. Duplicate IDs are rejected.

## Algorithms
**Insertion:** Compare the new ID with the current node, move left for smaller IDs and right for greater IDs, and insert at an empty child position.

**Search:** Compare the target ID at each node and continue left or right until found or an empty link is reached.

**Deletion:** (1) Leaf: remove directly. (2) One child: link the parent to the child. (3) Two children: copy the inorder successor (minimum ID in the right subtree), then remove that successor.

**Traversals:** Inorder = left, root, right (ascending IDs); preorder = root, left, right; postorder = left, right, root.

## Complexity
Let `n` be the number of records and `h` the height. Insert/search/delete take `O(h)`, average `O(log n)` in a reasonably balanced BST and worst-case `O(n)` in a skewed BST. Traversals take `O(n)`, storage is `O(n)`, and recursive stack space is up to `O(h)`.

A regular BST may become skewed if IDs are inserted in sorted order. A self-balancing AVL tree uses rotations to keep height logarithmic, supporting `O(log n)` operations.

## Conclusion
The project demonstrates BST ordering, recursion, record management, duplicate handling, traversal, deletion edge cases, and the effect of tree height on performance.
