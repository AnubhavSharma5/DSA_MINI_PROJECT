# Student Record BST Test Cases

Load the sample records with menu option `7` before the relevant tests.

| # | Test | Input/action | Expected result |
|---|---|---|---|
| 1 | Successful search | Option 2, ID `40` | Displays Arjun, department CSE |
| 2 | Missing ID | Option 2, ID `999` | Not-found message |
| 3 | Duplicate ID | Option 1, ID `50` | Duplicate rejected |
| 4 | Sorted display | Option 4 | IDs in ascending order: 10, 20, 30, 35, 40, 50, 60, 65, 70, 80 |
| 5 | Leaf deletion | Option 3, ID `10` | ID 10 removed |
| 6 | One-child deletion | Delete ID `60` in the initial sample | ID 60 is removed and its child ID 65 is reconnected |
| 7 | Two-child deletion | Option 3, ID `50` in the initial sample tree | Inorder successor replaces ID 50; BST ordering remains valid |
| 8 | Tree comparison | Option 8 | Prints height and insertion-comparison counts for both insertion orders |
| 9 | Empty tree | Start program, option 4 | Displays `Tree is empty.` |

Comparison counts are deterministic for the supplied insertion orders, but may vary if the implementation changes.
