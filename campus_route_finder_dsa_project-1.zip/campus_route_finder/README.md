# Campus Route Finder Using Graphs (C++)

**PPF Week 9 — DSA Mini Project**

A menu-driven C++ application that models campus locations as an undirected, unweighted graph. It demonstrates adjacency-list representation, Breadth-First Search (BFS), Depth-First Search (DFS), path reconstruction, reachability, and disconnected-location detection.

## Features

- Nine sample campus locations (more than the required eight).
- Adjacency-list graph representation.
- BFS shortest route by minimum number of edges.
- Path reconstruction using a parent/predecessor array.
- Iterative DFS to list locations reachable from a source.
- Reports locations unreachable from a chosen source.
- Handles unknown location names and invalid menu choices.
- Includes a test plan and report in `docs/`.

## Requirements

- A C++ compiler supporting C++17 (GCC, Clang, or a recent MSVC).
- VS Code is recommended but not required.

## Compile and run

### Windows (MinGW g++)
Open the terminal in this folder:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o campus_route_finder.exe
.\campus_route_finder.exe
```

### Linux / macOS

```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o campus_route_finder
./campus_route_finder
```

In the menu, choose option `1` first to see exact location names. Enter names with the same spelling and capitalization as shown (for example, `Main Gate` and `Computer Lab`).

## Sample test

Choose `3`, enter source `Main Gate`, and destination `Block 2`. One shortest route is:

`Main Gate -> Library -> Block 1 -> Block 2`

It contains 3 edges. Other equally short routes may exist for other source/destination pairs; BFS guarantees a route with the minimum edge count, not a geographically shortest distance in metres.

## Complexity

Let `V` be the number of vertices (locations) and `E` the number of edges (connections).

- Adjacency list storage: `O(V + E)`.
- BFS shortest route: `O(V + E)` time and `O(V)` auxiliary space.
- DFS reachability: `O(V + E)` time and `O(V)` auxiliary space.
- Reconstructing a returned route: `O(V)` time in the worst case.

## Repository structure

```text
campus-route-finder/
├── main.cpp
├── README.md
├── .gitignore
├── docs/
│   ├── PROJECT_REPORT.md
│   └── TEST_CASES.md
└── screenshots/
    └── README.md
```

## Limitations

- The example campus graph is predefined in source code; users do not add locations or edges through the menu.
- Connections are treated as two-way and all edges have equal cost. BFS is appropriate for this unweighted model. Weighted distances would require a weighted shortest-path algorithm such as Dijkstra's algorithm.
- The sample graph is connected. The disconnected-location feature works if the graph is changed to contain separate components.

## GitHub upload

1. Create a new **public** repository on GitHub named `campus-route-finder-dsa` (or another name you prefer). Do not initialize it with a README if you plan to push this folder as-is.
2. Extract the ZIP and open the extracted `campus_route_finder` folder in VS Code.
3. In the VS Code terminal, run:

```bash
git init
git add .
git commit -m "Add Campus Route Finder DSA mini project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/campus-route-finder-dsa.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. The repository URL above is a template, not a live repository link. The project is not uploaded until you run the push commands successfully.

Alternatively, use GitHub's web interface: create the repository, select **Add file → Upload files**, drag in the extracted project files, and commit the upload.

## Academic submission checklist

- [x] Source code with comments
- [x] README
- [x] Report
- [x] At least three documented test cases
- [ ] Capture screenshots of your own program running and add them to `screenshots/`
- [ ] Push the project to your GitHub account and paste the real repository URL in your submission
