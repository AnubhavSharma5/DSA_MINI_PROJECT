#include <algorithm>
#include <iostream>
#include <queue>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace std;

// Campus Route Finder: an undirected, unweighted graph implemented with an adjacency list.
class CampusGraph {
private:
    vector<string> locations;
    unordered_map<string, int> indexOf;
    vector<vector<int>> adjacency;

    bool validLocation(const string& name) const {
        return indexOf.find(name) != indexOf.end();
    }

public:
    CampusGraph() {
        // Eight or more sample campus locations, as required by the project brief.
        const vector<string> names = {
            "Main Gate", "Library", "Block 1", "Block 2", "Cafeteria",
            "Auditorium", "Parking", "Computer Lab", "Sports Ground"
        };
        for (const auto& name : names) addLocation(name);

        // Each connection is a two-way path. The graph is intentionally connected
        // in the default sample; the disconnected-location feature is still supported.
        addEdge("Main Gate", "Library");
        addEdge("Main Gate", "Parking");
        addEdge("Library", "Block 1");
        addEdge("Library", "Cafeteria");
        addEdge("Block 1", "Block 2");
        addEdge("Block 1", "Computer Lab");
        addEdge("Block 2", "Auditorium");
        addEdge("Cafeteria", "Sports Ground");
        addEdge("Parking", "Auditorium");
    }

    void addLocation(const string& name) {
        if (validLocation(name)) return;
        indexOf[name] = static_cast<int>(locations.size());
        locations.push_back(name);
        adjacency.emplace_back();
    }

    bool addEdge(const string& from, const string& to) {
        if (!validLocation(from) || !validLocation(to) || from == to) return false;
        int u = indexOf.at(from), v = indexOf.at(to);
        if (find(adjacency[u].begin(), adjacency[u].end(), v) == adjacency[u].end()) {
            adjacency[u].push_back(v);
            adjacency[v].push_back(u);
        }
        return true;
    }

    const vector<string>& getLocations() const { return locations; }

    void displayLocations() const {
        cout << "\nCampus locations:\n";
        for (size_t i = 0; i < locations.size(); ++i)
            cout << "  " << (i + 1) << ". " << locations[i] << '\n';
    }

    void displayGraph() const {
        cout << "\nGraph (adjacency list):\n";
        for (size_t i = 0; i < locations.size(); ++i) {
            cout << "  " << locations[i] << " -> ";
            for (size_t j = 0; j < adjacency[i].size(); ++j) {
                if (j) cout << ", ";
                cout << locations[adjacency[i][j]];
            }
            cout << '\n';
        }
    }

    // BFS visits neighbours level by level and reconstructs a minimum-edge path.
    vector<string> shortestRoute(const string& source, const string& destination) const {
        if (!validLocation(source) || !validLocation(destination)) return {};
        int s = indexOf.at(source), target = indexOf.at(destination);
        vector<bool> visited(locations.size(), false);
        vector<int> parent(locations.size(), -1);
        queue<int> q;
        visited[s] = true;
        q.push(s);

        while (!q.empty()) {
            int current = q.front(); q.pop();
            if (current == target) break;
            for (int next : adjacency[current]) {
                if (!visited[next]) {
                    visited[next] = true;
                    parent[next] = current;
                    q.push(next);
                }
            }
        }
        if (!visited[target]) return {};

        vector<string> route;
        for (int at = target; at != -1; at = parent[at]) route.push_back(locations[at]);
        reverse(route.begin(), route.end());
        return route;
    }

    // DFS returns every location reachable from the selected source.
    vector<string> reachableDFS(const string& source) const {
        vector<string> result;
        if (!validLocation(source)) return result;
        vector<bool> visited(locations.size(), false);
        vector<int> stack;
        stack.push_back(indexOf.at(source));
        while (!stack.empty()) {
            int current = stack.back(); stack.pop_back();
            if (visited[current]) continue;
            visited[current] = true;
            result.push_back(locations[current]);
            // Reverse insertion makes traversal order easier to read and deterministic.
            for (auto it = adjacency[current].rbegin(); it != adjacency[current].rend(); ++it)
                if (!visited[*it]) stack.push_back(*it);
        }
        return result;
    }

    vector<string> disconnectedFrom(const string& source) const {
        vector<string> reachable = reachableDFS(source);
        unordered_set<string> seen(reachable.begin(), reachable.end());
        vector<string> disconnected;
        for (const auto& name : locations)
            if (!seen.count(name)) disconnected.push_back(name);
        return disconnected;
    }
};

static void printList(const vector<string>& items) {
    if (items.empty()) {
        cout << "No locations found.\n";
        return;
    }
    for (size_t i = 0; i < items.size(); ++i) {
        if (i) cout << " -> ";
        cout << items[i];
    }
    cout << '\n';
}

static string readLine(const string& prompt) {
    cout << prompt;
    string value;
    getline(cin, value);
    return value;
}

int main() {
    CampusGraph campus;
    cout << "==========================================\n";
    cout << "       CAMPUS ROUTE FINDER (DSA)\n";
    cout << "==========================================\n";
    cout << "Find routes between campus locations using BFS and DFS.\n";

    while (true) {
        cout << "\n--------------- MAIN MENU ---------------\n";
        cout << "1. Show all campus locations\n";
        cout << "2. Show graph (adjacency list)\n";
        cout << "3. Find shortest route using BFS\n";
        cout << "4. Show DFS traversal / reachable locations\n";
        cout << "5. Find locations disconnected from a source\n";
        cout << "0. Exit\n";
        string choice = readLine("Enter choice: ");

        if (choice == "0") {
            cout << "Thank you for using Campus Route Finder.\n";
            break;
        } else if (choice == "1") {
            campus.displayLocations();
        } else if (choice == "2") {
            campus.displayGraph();
        } else if (choice == "3") {
            string source = readLine("Enter source location (exact name): ");
            string destination = readLine("Enter destination location (exact name): ");
            auto route = campus.shortestRoute(source, destination);
            if (route.empty()) {
                cout << "No route found. Check the location names or graph connectivity.\n";
            } else {
                cout << "Shortest route (minimum number of edges): ";
                printList(route);
                cout << "Number of edges: " << route.size() - 1 << '\n';
            }
        } else if (choice == "4") {
            string source = readLine("Enter starting location (exact name): ");
            auto reachable = campus.reachableDFS(source);
            if (reachable.empty()) cout << "Unknown location. Please use an exact name from the list.\n";
            else {
                cout << "DFS traversal / reachable locations: ";
                printList(reachable);
                cout << "Reachable location count: " << reachable.size() << '\n';
            }
        } else if (choice == "5") {
            string source = readLine("Enter starting location (exact name): ");
            if (find(campus.getLocations().begin(), campus.getLocations().end(), source) == campus.getLocations().end()) {
                cout << "Unknown location. Please use an exact name from the list.\n";
            } else {
                auto disconnected = campus.disconnectedFrom(source);
                if (disconnected.empty()) cout << "All campus locations are reachable from " << source << ".\n";
                else {
                    cout << "Locations not reachable from " << source << ": ";
                    printList(disconnected);
                }
            }
        } else {
            cout << "Invalid choice. Please enter 0, 1, 2, 3, 4, or 5.\n";
        }
    }
    return 0;
}
