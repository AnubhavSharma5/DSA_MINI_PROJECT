# Screenshots

Add genuine screenshots captured from your own program run here before submission. Recommended captures:

1. Main menu and list of all locations (option 1).
2. Adjacency list (option 2).
3. Successful BFS shortest route (option 3).
4. DFS traversal (option 4).
5. Disconnected-location result after testing a disconnected graph (option 5).

Suggested filenames: `01-menu.png`, `02-adjacency-list.png`, `03-bfs-route.png`, `04-dfs.png`, `05-disconnected.png`.
