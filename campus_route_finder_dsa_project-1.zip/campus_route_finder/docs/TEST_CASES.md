# Test Cases and Expected Results

Run the compiled program and use the menu. These cases are designed around the supplied sample graph.

| ID | Test | Input / steps | Expected result |
|---|---|---|---|
| TC-01 | Direct route | Select option 3; source `Main Gate`; destination `Library` | Route `Main Gate -> Library`; 1 edge |
| TC-02 | Multi-stop shortest route | Select option 3; source `Main Gate`; destination `Block 2` | Route `Main Gate -> Library -> Block 1 -> Block 2`; 3 edges |
| TC-03 | Same source and destination | Select option 3; source `Library`; destination `Library` | Route contains only `Library`; 0 edges |
| TC-04 | Invalid destination | Select option 3; source `Main Gate`; destination `Hostel` | No route found / check location names or connectivity |
| TC-05 | DFS traversal | Select option 4; source `Main Gate` | Lists all 9 locations because the sample graph is connected |
| TC-06 | Disconnected component | Temporarily remove all edges that connect `Sports Ground` to the rest of the graph (remove `Cafeteria`–`Sports Ground` and ensure it has no other edges), recompile, then select option 5 from `Main Gate` | `Sports Ground` is reported as not reachable |
| TC-07 | Invalid menu choice | Enter `9` at the menu | Displays an invalid-choice message and returns to the menu |

## Actual-output recording
Run each test on your own compiler. The expected results above are derived from the source graph; record the actual output after running and capture screenshots for submission. Do not label expected output as a screenshot or claim a test was executed unless you ran it.
