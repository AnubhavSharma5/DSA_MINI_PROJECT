# DSA Mini Project Report: Campus Route Finder Using Graphs

## 1. Aim
To develop a campus route finder using a graph and demonstrate graph representation, BFS, DFS, route reconstruction, reachability, and time/space complexity.

## 2. Problem statement
Campus buildings and facilities are represented as vertices, while walkways between them are represented as edges. The application finds a route with the minimum number of edges between a selected source and destination in an unweighted graph. It can also display reachable locations and identify locations not reachable from a chosen source.

## 3. Software and hardware requirements
- **Hardware:** Personal computer.
- **Software:** Operating system, C++17-compatible compiler, and optionally Visual Studio Code.

## 4. Graph design
The graph is undirected and unweighted. Each campus location is a vertex and each walkway is an edge. An adjacency list stores, for every vertex, a list of its neighbouring vertices.

Sample locations: Main Gate, Library, Block 1, Block 2, Cafeteria, Auditorium, Parking, Computer Lab, and Sports Ground.

Sample connections:
- Main Gate — Library
- Main Gate — Parking
- Library — Block 1
- Library — Cafeteria
- Block 1 — Block 2
- Block 1 — Computer Lab
- Block 2 — Auditorium
- Cafeteria — Sports Ground
- Parking — Auditorium

Because the connections are two-way, each edge is stored in both endpoints' adjacency lists.

## 5. Algorithms

### Breadth-First Search (BFS)
BFS uses a queue. It marks the source visited, explores all immediate neighbours, then proceeds level by level. A parent array records the predecessor of each discovered vertex. If the destination is reached, following parent links backwards and reversing the result reconstructs the route with the minimum number of edges.

**Steps:**
1. Mark every vertex unvisited and set each parent to `-1`.
2. Mark the source visited and add it to a queue.
3. Remove the front vertex and inspect its neighbours.
4. For each unvisited neighbour, mark it visited, store its parent, and enqueue it.
5. Stop when the destination is reached or the queue becomes empty.
6. If reachable, follow parent links from destination to source and reverse the path.

### Depth-First Search (DFS)
DFS uses an explicit stack to explore one branch as far as possible before backtracking. The visited array prevents repeated processing. The same traversal can identify every vertex reachable from a source.

### Disconnected locations
The program runs reachability from the selected source. Any graph vertex absent from the reachable set is reported as disconnected from that source. The supplied sample graph is connected, so the default example reports that all locations are reachable. The feature can be verified by removing connections or adding another component in the code.

## 6. Sample input and output

**Input:** Menu option `3`; source `Main Gate`; destination `Block 2`.

**Expected output (route):**

```text
Shortest route (minimum number of edges): Main Gate -> Library -> Block 1 -> Block 2
Number of edges: 3
```

The exact route selected can depend on adjacency order when multiple shortest routes exist. BFS still guarantees a minimum-edge route.

## 7. Complexity analysis
Let `V` be the number of vertices and `E` be the number of edges.

| Operation / representation | Time complexity | Space complexity |
|---|---:|---:|
| Adjacency-list storage | — | O(V + E) |
| BFS | O(V + E) | O(V) auxiliary |
| DFS | O(V + E) | O(V) auxiliary |
| Adjacency-matrix storage (comparison) | — | O(V²) |
| Scanning neighbours with adjacency matrix | O(V) per vertex scan | O(V²) overall traversal |

An adjacency list is generally more space-efficient for sparse graphs because it stores existing edges. An adjacency matrix offers a simple, constant-time edge-presence check but allocates space for every possible vertex pair.

## 8. Testing
The detailed test cases are in `TEST_CASES.md`. They cover a direct route, a multi-stop shortest route, an unreachable/unknown destination, DFS reachability, and disconnected components as a graph modification.

## 9. Conclusion
The Campus Route Finder demonstrates how graphs model real-world connections. BFS finds a minimum-edge route in an unweighted graph, while DFS explores the locations reachable from a source. The adjacency-list implementation provides `O(V + E)` traversal time and `O(V + E)` graph storage, making it suitable for a sparse campus map.

## 10. Future improvements
- Allow users to add locations and connections at runtime.
- Load campus data from a file.
- Add a graphical user interface and a visual campus map.
- Store distances or walking times as edge weights and use Dijkstra's algorithm.
